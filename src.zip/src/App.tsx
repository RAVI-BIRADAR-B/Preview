import React from 'react';
import logo from './logo.svg';
import './App.css';
import Home from './component/home';


function App() {
  return (
    <div >
      <Home/>
    </div>
  );
}

export default App;
